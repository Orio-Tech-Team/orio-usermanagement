import { typeOrmConfig } from './typeorm.config';
export = typeOrmConfig;
